SVT original artwork v1

Bathos Pty Ltd dedicates this original artwork and this notice under CC0 1.0.
No attribution is required. See CC0-1.0.txt for the full legal text.
Includes marks, avatars and outlined document icons, with SVG/PNG/ICO/ICNS exports.
Use small artwork at 16-32 px and regular artwork at 48 px and above.
Light/dark identify the intended background. Tintable inline SVG uses currentColor.
This archive contains no Phosphor-derived filled UI icons.
CC0 does not affect trademark or patent rights. Use does not imply endorsement.
